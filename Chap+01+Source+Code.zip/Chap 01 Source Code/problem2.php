<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Problem 2</title>
</head>
<body>
    <?php
    // 2) Write a PHP Program to make use of comments in hello world program

    echo "Hello World";
    // Single Line comment 
    // Another comment 

    /*
     $a = 33;
    if ($a == 33){
        echo "hi";
    }
    */
    # Also used for single line comment.....


    
    ?>
</body>
</html>