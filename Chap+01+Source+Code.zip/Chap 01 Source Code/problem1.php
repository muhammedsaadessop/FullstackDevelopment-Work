<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Problem 1</title>
</head>
<body>
<!-- Write a PHP Program to make use of all arithmetic operators in echo statement
 -->
<?php
    // +, -, /, *, %
    echo "Arithmetic Operators";
    echo "<br>";
    $a = 10;
    $b = 20;
    echo  "Addition = ".$a + $b;
    echo "<br>";
    echo  "Subtraction = ".$a - $b;
    echo "<br>";
    echo  "Division = ".$a / $b;
    echo "<br>";
    echo  "Multiplication = ".$a * $b;
    echo "<br>";
    echo  "Modo = ".$a % $b;

?>
</body>
</html>