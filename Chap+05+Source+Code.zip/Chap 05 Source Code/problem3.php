<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chapter 05 Problem 3</title>
</head>
<body>
    <!-- 3) Write a PHP Program to find max and min number from a list of numbers
 -->
 <?php
  $num = array(1,2,55,12,43,65,872,3,73);
//   echo min($num);
    echo max($num);
    echo "<br>";
    echo max(1,2,34,4,64,223,541,21)
 ?>
</body>
</html>