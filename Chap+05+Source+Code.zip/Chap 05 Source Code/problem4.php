<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chapter 05 Problem 4</title>
</head>
<body>
    <!-- 4) Write a PHP Program to find power of any number 
 -->
    <?php
    echo pow(1000,1) // 2^3 = 8
    
    ?>
</body>
</html>