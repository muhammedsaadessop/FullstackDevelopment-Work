<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String Operators</title>
</head>
<body>
    <?php
    $f_name = "Faisal ";
    $l_name = "Jafri";

    // echo $f_name.$l_name;
    $f_name .= $l_name;
    echo $f_name;
    $n = "3";
    $val = "123";
    echo $n.$val;




    ?>
</body>
</html>