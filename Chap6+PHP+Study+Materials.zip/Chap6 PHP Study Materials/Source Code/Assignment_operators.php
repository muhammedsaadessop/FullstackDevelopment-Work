<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment Operators</title>
</head>
<body>
    <?php
    $x = 8;
    $x += 1; // x = x +2 - > 8 + 2 -> 10->x
    echo $x;
    echo "<br/>";
    $y = 10;
    $y -= 2; 
    echo $y;

    echo "<br/>";
    $z = 10;
    $z *= 2; 
    echo $z;
 
    echo "<br/>";
    $a = 10;
    $a /= 2; 
    echo $a; // 10/2

    echo "<br/>";
    $b = 10;
    $b %= 2; 
    echo $b; // 
    ?>
</body>
</html>