<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment Operators</title>
</head>
<body>
    <?php
    $a = 30;
    $b = 30;

    $result = ($a > $b) ? "A is greater than B":"A is not greater than B";
    echo $result;

    ?>
</body>
</html>