<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chapter 03 Problem1</title>
</head>
<!-- 1) Write a PHP Program to create array of different programing languages, access array element.
 -->
<body>
    <?php
    $lang = array("PHP","Python", "C++","C Sharp","Java");
    echo $lang[4]
    
    ?>
</body>
</html>